ALTER TABLE `invoice_items` DROP COLUMN `transactionDate`;
